Contents
--------
H1N1.fasta
  Reference / seed genome used to create the donor population.

scripts/
  Donor_create_xml.py          # build donor XML from reference FASTA
  Create_Santa_xml.py          # build recipient XML after bottleneck inoculum
  H1N1_Donor_Bottleneck.xml    # existing donor XML (generated previously)
  Run_SANTA.smk                # organise FASTA + run santa.jar
  Convert_to_RInput.py         # convert simulation outputs to R CSV input
  Create_*_dataset_noerror.smk # downstream no-error dataset pipelines

santa-sim_dist/santa.jar
  SANTA-SIM jar called by Run_SANTA.smk

Note: large simulated population FASTAs (H1N1_Donor.fasta, raw_santa recipients,
Nb/{rep} outputs) are NOT included.
