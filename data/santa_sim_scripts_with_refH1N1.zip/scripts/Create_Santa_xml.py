import xml.etree.ElementTree as ET
import re


class SantaXml:
    def __init__(self, fasta_name: str, pop_size: int):
        self.fasta = fasta_name
        self.pop=pop_size
        self.total_g=20

    def prettify(self, elem, level=0):
        indent = "  "
        i = "\n" + level * indent
        if len(elem):
                if not elem.text or not elem.text.strip():
                        elem.text = i + indent
                for child in elem:
                        self.prettify(child, level + 1)
                if not child.tail or not child.tail.strip():
                        child.tail = i
        if level and (not elem.tail or not elem.tail.strip()):
                elem.tail = i
        return elem


    def build_xml(self):
        santa = ET.Element("santa")
######################################################################################
        replicates = ET.SubElement(santa, "replicates")
        replicates.text=str(1)
######################################################################################
        simulation = ET.SubElement(santa, "simulation")
######################################################################################
        genome=ET.SubElement(simulation, "genome")
        length=ET.SubElement(genome,"length")
        length.text=str(13158)
        sequences=ET.SubElement(genome,"sequences")
        sequences.set("file",f"{self.fasta}")
        feature=ET.SubElement(genome,"feature")
        name=ET.SubElement(feature,"name")
        name.text="H1N1"
        type=ET.SubElement(feature,"type")
        type.text="nucleotide"
        coordinates=ET.SubElement(feature,"coordinates")
        coordinates.text="1-13158"
######################################################################################
        population=ET.SubElement(simulation, "population")
        populationSize=ET.SubElement(population, "populationSize")
        populationSize.text=str(self.pop)
        inoculum=ET.SubElement(population, "inoculum")
        inoculum.text="all"
######################################################################################
        populationType=ET.SubElement(simulation, "populationType")
        populationType.text="dynamicPopulation"
#######################################################################################
        growthModel=ET.SubElement(simulation, "growthModel")
        growthRate=ET.SubElement(growthModel, "growthRate")
        growthRate.text=str(1.8)
        carryingPopulation=ET.SubElement(growthModel, "carryingPopulation")
        carryingPopulation.text=str(1500000)
#######################################################################################
        fitnessFunction=ET.SubElement(simulation, "fitnessFunction")
        neutralFitness=ET.SubElement(fitnessFunction, "neutralFitness")
        fitness_feature=ET.SubElement(neutralFitness, "feature")
        fitness_feature.text="H1N1"
        sites=ET.SubElement(neutralFitness, "sites")
        sites.text="1-13158"
#######################################################################################
        mutator=ET.SubElement(simulation, "mutator")
        nucleotideMutator=ET.SubElement(mutator,"nucleotideMutator")
        mutationRate=ET.SubElement(nucleotideMutator,"mutationRate")
        mutationRate.text="1.5e-05"
        transitionBias=ET.SubElement(nucleotideMutator,"transitionBias")
        transitionBias.text=str(2)
#######################################################################################
        replicator=ET.SubElement(simulation, "replicator")
        clonalReplicator=ET.SubElement(replicator, "clonalReplicator")
#######################################################################################
        epoch=ET.SubElement(simulation, "epoch")
        generationCount=ET.SubElement(epoch,"generationCount")
        generationCount.text=str(20)
#######################################################################################
        samplingSchedule=ET.SubElement(simulation, "samplingSchedule")
        return (santa)
#######################################################################################

class DonorXml(SantaXml):
    def __init__(self, fasta_name, pop_size):
        super().__init__(fasta_name, pop_size)
        self.role="Donor"

    def add_Donorsampler(self,root):
        samplingSchedule=root.find("samplingSchedule")
        F_sampler=ET.SubElement(samplingSchedule,"sampler")
        atFrequency=ET.SubElement(F_sampler,"atFrequency")
        atFrequency.text=str(1)
        F_fileName=ET.SubElement(F_sampler,"fileName")
        F_fileName.text=f"stats_{self.role}.csv"
        statistics=ET.SubElement(F_sampler,"statistics")
        G_sampler=ET.SubElement(samplingSchedule,"sampler")
        atGeneration=ET.SubElement(G_sampler,"atGeneration")
        atGeneration.text=str(self.total_g)
        G_fileName=ET.SubElement(G_sampler,"fileName")
        G_fileName.text="H1N1_Donor.csv"
        alleleFrequency=ET.SubElement(G_sampler,"alleleFrequency")
        G_feature=ET.SubElement(alleleFrequency,"feature")
        G_feature.text="H1N1"
        G_sites=ET.SubElement(alleleFrequency,"sites")
        G_sites.text="1-13158"
#######################################################################################
        S_sampler=ET.SubElement(samplingSchedule,"sampler")
        S_atGeneration=ET.SubElement(S_sampler,"atGeneration")
        S_atGeneration.text=str(self.total_g)
        S_fileName=ET.SubElement(S_sampler,"fileName")
        S_fileName.text="H1N1_Donor.fasta"
        S_alignment=ET.SubElement(S_sampler,"alignment")
        S_sampleSize=ET.SubElement(S_alignment,"sampleSize")
        S_sampleSize.text=str(self.pop)
        S_format=ET.SubElement(S_alignment,"format")
        S_format.text="FASTA"
        S_label=ET.SubElement(S_alignment,"label")
        S_label.text="H1N1_Donor_%s"

    def add_Bottlenecksampler (self,samplingSchedule,Nb_list:list):
        for Nb in Nb_list:
                for Nb_relicates in range(1,6):
                        print(Nb_relicates)
                        Nb_sampler=ET.SubElement(samplingSchedule,"sampler")
                        Nb_atGeneration=ET.SubElement(Nb_sampler,"atGeneration")
                        Nb_atGeneration.text=str(self.total_g)
                        Nb_fileName=ET.SubElement(Nb_sampler,"fileName")
                        Nb_fileName.text=f"H1N1_Recipient_{Nb}_{Nb_relicates}.fasta"
                        Nb_alignment=ET.SubElement(Nb_sampler,"alignment")
                        Nb_sampleSize=ET.SubElement(Nb_alignment,"sampleSize")
                        Nb_sampleSize.text=str(Nb)
                        Nb_format=ET.SubElement(Nb_alignment,"format")
                        Nb_format.text="FASTA"
                        Nb_label=ET.SubElement(Nb_alignment,"label")
                        Nb_label.text=f"H1N1_Recipient_{Nb}_{Nb_relicates}_%s"
    

class RecipientXml(SantaXml):
    def __init__(self, fasta_name, pop_size):
        super().__init__(fasta_name, pop_size)
        self.role="Recipient"
        self.name=fasta_name    
        
    def extract_nb_replicate(filename: str) -> tuple[int, int]:
        PATTERN = re.compile(r"H1N1_Recipient_(\d+)_(\d+)\.fasta$") # match pattern
        m = PATTERN.search(filename)
        nb, replicate = map(int, m.groups())
        return nb, replicate

    def add_Statsampler(self,root,Nb,rep):
        samplingSchedule=root.find("samplingSchedule")
        F_sampler=ET.SubElement(samplingSchedule,"sampler")
        atFrequency=ET.SubElement(F_sampler,"atFrequency")
        atFrequency.text=str(1)
        F_fileName=ET.SubElement(F_sampler,"fileName")
        F_fileName.text=f"stats_{self.role}_{Nb}_{rep}.csv"
        statistics=ET.SubElement(F_sampler,"statistics")

    def add_PostBottleneck (self,samplingSchedule,Nb, Nb_replicates):
        for post_generations in range(4,24,4):
                pNb_sampler=ET.SubElement(samplingSchedule,"sampler")
                pNb_atGeneration=ET.SubElement(pNb_sampler,"atGeneration")
                pNb_atGeneration.text=str(post_generations)
                pNb_fileName=ET.SubElement(pNb_sampler,"fileName")
                pNb_fileName.text=f"H1N1_Recipient_{Nb}_{Nb_replicates}_{post_generations}.fasta"
                pNb_alignment=ET.SubElement(pNb_sampler,"alignment")
                pNb_sampleSize=ET.SubElement(pNb_alignment,"sampleSize")
                pNb_sampleSize.text=str(self.pop)
                pNb_format=ET.SubElement(pNb_alignment,"format")
                pNb_format.text="FASTA"
                pNb_label=ET.SubElement(pNb_alignment,"label")
                pNb_label.text=f"H1N1_Recipient_{Nb}_{Nb_replicates}_{post_generations}_%s"

 

