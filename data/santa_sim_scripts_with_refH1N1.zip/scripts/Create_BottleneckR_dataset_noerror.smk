import math

rep=[1,2,3,4,5]
coverage=2000
Nb=[1,10,20,30,40,50]

rule all:
    input:
        expand("BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R1.fastq",Nb=Nb, rep=rep),    
        expand("BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R2.fastq",Nb=Nb, rep=rep),
        expand("BottleneckRDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_12.bam",Nb=Nb, rep=rep),
        expand("BottleneckRDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_12_entropy.txt",Nb=Nb, rep=rep)

rule wgsim_single:
    input:  
        fasta="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_12.fasta"
    output:
        fastq1="BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R1.fastq",
        fastq2="BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R2.fastq"
    params:
        N= math.ceil(int(2000)*13158 / 125),
        outdir=lambda wc: f"BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{wc.Nb}_{wc.rep}_12"
    shell:
        """
        mkdir -p BottleneckRDataset_noerror/raw_reads
        iss generate --genomes {input.fasta} --abundance uniform --mode perfect --n_reads {params.N} --output {params.outdir}
        rm {params.outdir}_abundance.txt
        rm {params.outdir}.iss.tmp.0.vcf
        rm {params.outdir}.iss.tmp.1.vcf
        """


# Diversitools path: DiversiTools/bin/diversiutils.pl
#snakemake --cores 4 -s Create_generation_dataset_noerror.smk 

rule mapping:
    input:
        fastq1="BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R1.fastq",
        fastq2="BottleneckRDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_12_R2.fastq"
    output:
        sam=temp("BottleneckRDataset_noerror/mapped_reads/{Nb}_{rep}_12.sam"),
        bam=temp("BottleneckRDataset_noerror/mapped_reads/{Nb}_{rep}_12.bam"),
        sort_bam="BottleneckRDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_12.bam"
    shell:
        """
          mkdir -p BottleneckRDataset_noerror/mapped_reads  
          bowtie2 -x H1N1_index/H1N1_index -1 {input.fastq1} -2 {input.fastq2} -S {output.sam}
          samtools view -bS {output.sam} > {output.bam}
          samtools sort -o {output.sort_bam} {output.bam}
          samtools index {output.sort_bam}  
        """


rule variant_calling:
    input:
        bam="BottleneckRDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_12.bam"
    
    output:
        entropy="BottleneckRDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_12_entropy.txt"
    params:
        prefix=lambda wc: f"BottleneckRDataset_noerror/variant_calling/H1N1_Recipient_{wc.Nb}_{wc.rep}_12"
    shell:
        """
        mkdir -p GenerationDataset_noerror/variant_calling
        DiversiTools/bin/diversiutils_linux -bam {input.bam} -ref H1N1_index/H1N1.fasta -stub {params.prefix}

        """
    