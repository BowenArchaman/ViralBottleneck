from pathlib import Path
from collections import Counter
import pandas as pd
from Bio import SeqIO           # Biopython parser
##################################################################################################
#coverage dataset
from pathlib import Path
import pandas as pd
NB          = 50                          # H1N1 donor ID
REPS        = range(1, 6)                 # 1-5
COVERAGES   = [10, 100, 1000, 10000]      # four depth subsamplings
OUT_DIR     = Path("CoverageDataset_noerror/R_input")
OUT_DIR.mkdir(exist_ok=True)

def convert_one(file_in: Path, file_out: Path) -> None:
    """
    Read one entropy.txt file and write position-wise A/T/C/G counts.
    """
    df = pd.read_csv(file_in, sep="\t", dtype=str)                # 1
    df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]] = (
        df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]]
          .apply(pd.to_numeric, errors="coerce")                  # 2
          .fillna(0)                                              # 3
          .astype(int)                                            # 4
    )

    out = pd.DataFrame({
        "position": df["Position"].astype(int),
        "segment": 1,
        "A": df["Acnt"],
        "T": df["Tcnt"],
        "C": df["Ccnt"],
        "G": df["Gcnt"],
        "Non/Syn":"Syn"
    })

    out.to_csv(file_out, sep=",", index=False)                   # 5
    print(f"✔ wrote {file_out}")

def main():
    for rep in REPS:
        for cov in COVERAGES:
            in_file  = Path(f"CoverageDataset_noerror/variant_calling/"
                             f"H1N1_Recipient_{NB}_{rep}_{cov}_entropy.txt")
            out_file = OUT_DIR / f"H1N1_Recipient_{NB}_{rep}_{cov}.csv"
            convert_one(in_file, out_file)
if __name__ == "__main__":
    main()
#
#Generation dataset
from pathlib import Path
import pandas as pd
NB          = 50                          # H1N1 donor ID
REPS        = range(1, 6)                 # 1-5
GENERATIONS   = [4,8,12,16,20]      # four depth subsamplings
OUT_DIR     = Path("GenerationDataset_noerror/R_input")
OUT_DIR.mkdir(exist_ok=True)

def convert_one(file_in: Path, file_out: Path) -> None:
    """
    Read one entropy.txt file and write position-wise A/T/C/G counts.
    """
    df = pd.read_csv(file_in, sep="\t", dtype=str)                # 1
    df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]] = (
        df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]]
          .apply(pd.to_numeric, errors="coerce")                  # 2
          .fillna(0)                                              # 3
          .astype(int)                                            # 4
    )

    out = pd.DataFrame({
        "position": df["Position"].astype(int),
        "segment": 1,
        "A": df["Acnt"],
        "T": df["Tcnt"],
        "C": df["Ccnt"],
        "G": df["Gcnt"],
        "Non/Syn":"Syn"
    })

    out.to_csv(file_out, sep=",", index=False)                   # 5
    print(f"✔ wrote {file_out}")

def main():
    for rep in REPS:
        for gen in GENERATIONS:
            in_file  = Path(f"GenerationDataset_noerror/variant_calling/"
                             f"H1N1_Recipient_{NB}_{rep}_{gen}_entropy.txt")
            out_file = OUT_DIR / f"H1N1_Recipient_{NB}_{rep}_{gen}.csv"
            convert_one(in_file, out_file)
if __name__ == "__main__":
    main()


#Bottleneck T
#convert to Bottleneck theoretical dataset
from pathlib import Path
from collections import Counter
import pandas as pd
from Bio import SeqIO           # Biopython parser


             # 1-5

def count_bases_per_position(fasta_file: Path) -> pd.DataFrame:
    records = list(SeqIO.parse(fasta_file, "fasta"))
    if not records:
        raise ValueError(f"No records found in {fasta_file}")
    length = len(records[0].seq)
    # initialise counters for every site
    counters = [Counter() for _ in range(length)]
    for r in records:
        for i, base in enumerate(str(r.seq).upper()):
            counters[i][base] += 1
    # build the tidy table
    return pd.DataFrame(
        {
            "position": range(1, length + 1),
            "segment": 1,
            "A": [counters[i].get("A", 0) for i in range(length)], #dict.get(key, default) is a dictionary method that never raises KeyError.
            "T": [counters[i].get("T", 0) for i in range(length)],
            "C": [counters[i].get("C", 0) for i in range(length)],
            "G": [counters[i].get("G", 0) for i in range(length)],
            "Non/Syn": "Syn"
        }
    )
REPS=[1,2,3,4,5]
NBs = [1,10,20,30,40,50]
out_dir = Path("BottleneckTDataset_noerror/R_input")
out_dir.mkdir(exist_ok=True)
for NB in NBs:
    for rep in REPS:
        fasta = Path(f"{NB}/{rep}/H1N1_Recipient_{NB}_{rep}_0.fasta")
        table = count_bases_per_position(fasta)
        # (optional) convert to FREQUENCIES instead of counts:
        # table[["A","T","C","G"]] = table[["A","T","C","G"]].div(len(list(SeqIO.parse(fasta, 'fasta'))))
        table.to_csv(out_dir / f"H1N1_Recipient_{NB}_{rep}_0.csv", sep=",", index=False)
        print(f"Wrote {out_dir/f'H1N1_Recipient_{NB}_{rep}_0.csv'}")



# Bottleneck R

from pathlib import Path
import pandas as pd
NB          = [1,10,20,30,40,50]                          # H1N1 donor ID
REPS        = range(1, 6)                 # 1-5
GENERATIONS   = 12     # four depth subsamplings
OUT_DIR     = Path("BottleneckRDataset_noerror/R_input")
OUT_DIR.mkdir(exist_ok=True)

def convert_one(file_in: Path, file_out: Path) -> None:
    """
    Read one entropy.txt file and write position-wise A/T/C/G counts.
    """
    df = pd.read_csv(file_in, sep="\t", dtype=str)                # 1
    df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]] = (
        df[["Acnt", "Tcnt", "Ccnt", "Gcnt"]]
          .apply(pd.to_numeric, errors="coerce")                  # 2
          .fillna(0)                                              # 3
          .astype(int)                                            # 4
    )

    out = pd.DataFrame({
        "position": df["Position"].astype(int),
        "segment": 1,
        "A": df["Acnt"],
        "T": df["Tcnt"],
        "C": df["Ccnt"],
        "G": df["Gcnt"],
        "Non/Syn":"Syn"
    })

    out.to_csv(file_out, sep=",", index=False)                   # 5
    print(f"✔ wrote {file_out}")

def main():
    for rep in REPS:
        for Nb in NB:
            in_file  = Path(f"BottleneckRDataset_noerror/variant_calling/"
                             f"H1N1_Recipient_{Nb}_{rep}_12_entropy.txt")
            out_file = OUT_DIR / f"H1N1_Recipient_{Nb}_{rep}_12.csv"
            convert_one(in_file, out_file)
if __name__ == "__main__":
    main()

#Transmission pairs creation
# Coverage
from pathlib import Path
import pandas as pd
OUT_DIR     = Path("CoverageDataset_noerror/R_input")
replicates = range(1, 6)             # 1, 2, 3, 4, 5
coverages  = [10, 100, 1000, 10000]  # 10-fold to 10 000-fold

recipient = [f"H1N1_Recipient_50_{r}_{c}"
          for r in replicates        # outer loop: replicate
          for c in coverages]

out=pd.DataFrame({
        "donor": "H1N1_Donor_20",
        "recipient": recipient
    
})
out.to_csv(f"{OUT_DIR}/Coverage_transmission_pairs.csv",sep=",", index=False)

# Generation
from pathlib import Path
import pandas as pd
OUT_DIR     = Path("GenerationDataset_noerror/R_input")
replicates = range(1, 6)             # 1, 2, 3, 4, 5
generations  = [4,8,12,16,20]  # 10-fold to 10 000-fold

recipient = [f"H1N1_Recipient_50_{r}_{g}"
          for r in replicates        # outer loop: replicate
          for g in generations]

out=pd.DataFrame({
        "donor": "H1N1_Donor_20",
        "recipient": recipient
    
})
out.to_csv(f"{OUT_DIR}/Generation_transmission_pairs.csv",sep=",", index=False)

# Bottleneck-T
from pathlib import Path
import pandas as pd
OUT_DIR     = Path("BottleneckTDataset_noerror/R_input")
replicates = range(1, 6)             # 1, 2, 3, 4, 5
Nbs  = [1,10,20,30,40,50]  # 10-fold to 10 000-fold

recipient = [f"H1N1_Recipient_{Nb}_{r}_0"
          for r in replicates        # outer loop: replicate
          for Nb in Nbs]

out=pd.DataFrame({
        "donor": "H1N1_Donor_20",
        "recipient": recipient
    
})
out.to_csv(f"{OUT_DIR}/BottleneckT_transmission_pairs.csv",sep=",", index=False)

# Bottleneck-R
from pathlib import Path
import pandas as pd
OUT_DIR     = Path("BottleneckRDataset_noerror/R_input")
replicates = range(1, 6)             # 1, 2, 3, 4, 5
Nbs  = [1,10,20,30,40,50]  # 10-fold to 10 000-fold

recipient = [f"H1N1_Recipient_{Nb}_{r}_12"
          for r in replicates        # outer loop: replicate
          for Nb in Nbs]

out=pd.DataFrame({
        "donor": "H1N1_Donor_20",
        "recipient": recipient
    
})
out.to_csv(f"{OUT_DIR}/BottleneckR_transmission_pairs.csv",sep=",", index=False)

#plot coverage:
import glob, re, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogLocator, ScalarFormatter

# ───────── helpers ─────────
def parse_info(recipient: str):
    parts = recipient.split("_")
    return int(parts[-2]), int(parts[-1])          # replicate, coverage

def pretty(name: str) -> str:
    return (name.replace("_", " ")
                .replace("-", " ")
                .title())

# ───────── load data ─────────
dfs = []
for fp in glob.glob("CoverageDataset_noerror/R_input/H1N1_ob_*.csv"):
    raw = re.search(r"CoverageDataset_noerror/R_input/H1N1_ob_(.*)\.csv", fp).group(1)
    d   = pd.read_csv(fp)
    d["method"] = pretty(raw)
    dfs.append(d)

df = pd.concat(dfs, ignore_index=True)
df[["replicate", "coverage"]] = df["recipient"].apply(
    lambda s: pd.Series(parse_info(s), index=["replicate", "coverage"])
)

coverage_order = sorted(df["coverage"].unique())
df["coverage"] = pd.Categorical(df["coverage"],
                                ordered=True,
                                categories=coverage_order)

# ───────── layout params ─────────
method_order = ["Beta Binomial Approximate",
                "Beta Binomial Exact",
                "Binomial",
                "Kl",
                "Presence Absence"]

halfwidth   = 0.30                              # width per method block
method_step = 2*halfwidth/(len(method_order)-1)
method_shift = {m: -halfwidth+i*method_step
                for i, m in enumerate(method_order)}

replicate_shift = {1:-0.04, 2:-0.02, 3:0, 4:0.02, 5:0.04}

palette = {"Beta Binomial Approximate":"#E66C2C",
           "Beta Binomial Exact"     :"#FFB347",
           "Binomial"                :"#DD1155",
           "Kl"                      :"#2D68C4",
           "Presence Absence"        :"#7FC8F8"}
markers = {1:"o", 2:"s", 3:"v", 4:"^", 5:"P"}

# ───────── plotting ─────────
fig, ax = plt.subplots(figsize=(13,6))          # wider so legend never crowds

for _, row in df.iterrows():
    cov_idx = coverage_order.index(row["coverage"])
    x = cov_idx + method_shift[row["method"]] + replicate_shift[row["replicate"]]
    ax.errorbar(
        x, row["transmission_bottleneck_size"],
        yerr=[[row["transmission_bottleneck_size"]-row["CI_low"]],
              [row["CI_high"]-row["transmission_bottleneck_size"]]],
        fmt=markers[row["replicate"]],
        ms=6, color=palette[row["method"]], ecolor=palette[row["method"]],
        markeredgewidth=0.5
    )

plt.rcParams.update({"xtick.labelsize":14, "ytick.labelsize":14,
                     "xtick.major.size":8, "xtick.major.width":1.5,
                     "ytick.major.size":8, "ytick.major.width":1.5})
# guide lines & labels

ax.axhline(50, ls="--", lw=1, color="red")

ax.set_xticks(range(len(coverage_order)))
ax.set_xticklabels(coverage_order)
ax.set_xlabel("Coverage",  fontsize=16)

# ----- y-axis ticks: include 50 explicitly -----
tick_list = [1,2,5,10,20,50,100,200,500]
ax.set_yscale("log")
ax.set_yticks(tick_list)
ax.get_yaxis().set_major_formatter(ScalarFormatter())
ax.set_ylabel("Estimation of bottleneck size",  fontsize=16)

ax.set_title("Bottleneck size 50, Post-bottleneck 3days",  fontsize=18)
method_handles = [
    Line2D([], [], marker=markers[3], linestyle='',
           markerfacecolor=palette[m], markeredgecolor=palette[m],
           markersize=7, label=m)
    for m in method_order
]

# 2) shape legend (replicates)
replicate_handles = [
    Line2D([], [], marker=markers[r], linestyle='',
           markerfacecolor='grey', markeredgecolor='grey',
           markersize=7, label=f"r{r}")
    for r in sorted(replicate_shift)
]

# ───────── figure-level legend (never clipped) ─────────
leg_methods = fig.legend(          # figure-level legend = never clipped
    handles=method_handles,
    title="Method",
    bbox_to_anchor=(1.02, 0.8),   # right outside, top-aligned
    loc="upper left",
    borderaxespad=0.0,
    frameon=False,
    ncol=1,
    fontsize=13, title_fontsize=14                         # vertical
)

# ---  A second stacked legend for replicates -----------------------
leg_reps = fig.legend(
    handles=replicate_handles,
    title="Replicate",
    bbox_to_anchor=(1.02, 0.50),   # right outside, ~40 % down
    loc="upper left",
    borderaxespad=0.0,
    frameon=False,
    ncol=1,
    fontsize=13, title_fontsize=14
)

# reserve 25 % of the canvas for the legends *before* tightening
fig.subplots_adjust(right=0.75) 


plt.tight_layout()
plt.show()
#fig.savefig("bottleneck_panel.png", dpi=300, bbox_inches="tight")
#print("Saved figure as bottleneck_panel.png")

# plot generation
import glob, re, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogLocator, ScalarFormatter

# ───────── helpers ─────────
def parse_info(recipient: str):
    parts = recipient.split("_")
    return int(parts[-2]), int(parts[-1])          # replicate, coverage

def pretty(name: str) -> str:
    return (name.replace("_", " ")
                .replace("-", " ")
                .title())

# ───────── load data ─────────
dfs = []
for fp in glob.glob("GenerationDataset_noerror/R_input/H1N1_ob_*.csv"):
    raw = re.search(r"GenerationDataset_noerror/R_input/H1N1_ob_(.*)\.csv", fp).group(1)
    d   = pd.read_csv(fp)
    d["method"] = pretty(raw)
    dfs.append(d)

df = pd.concat(dfs, ignore_index=True)
df[["replicate", "generation"]] = df["recipient"].apply(
    lambda s: pd.Series(parse_info(s), index=["replicate", "generation"])
)

generation_order = sorted(df["generation"].unique())
df["generation"] = pd.Categorical(df["generation"],
                                ordered=True,
                                categories=generation_order)

# ───────── layout params ─────────
method_order = ["Beta Binomial Approximate",
                "Beta Binomial Exact",
                "Binomial",
                "Kl",
                "Presence Absence"]

halfwidth   = 0.30                              # width per method block
method_step = 2*halfwidth/(len(method_order)-1)
method_shift = {m: -halfwidth+i*method_step
                for i, m in enumerate(method_order)}

replicate_shift = {1:-0.04, 2:-0.02, 3:0, 4:0.02, 5:0.04}

palette = {"Beta Binomial Approximate":"#E66C2C",
           "Beta Binomial Exact"     :"#FFB347",
           "Binomial"                :"#DD1155",
           "Kl"                      :"#2D68C4",
           "Presence Absence"        :"#7FC8F8"}
markers = {1:"o", 2:"s", 3:"v", 4:"^", 5:"P"}

plt.rcParams.update({"xtick.labelsize":14, "ytick.labelsize":14,
                     "xtick.major.size":8, "xtick.major.width":1.5,
                     "ytick.major.size":8, "ytick.major.width":1.5})
# ───────── plotting ─────────
fig, ax = plt.subplots(figsize=(13,6))          # wider so legend never crowds

for _, row in df.iterrows():
    cov_idx = generation_order.index(row["generation"])
    x = cov_idx + method_shift[row["method"]] + replicate_shift[row["replicate"]]
    ax.errorbar(
        x, row["transmission_bottleneck_size"],
        yerr=[[row["transmission_bottleneck_size"]-row["CI_low"]],
              [row["CI_high"]-row["transmission_bottleneck_size"]]],
        fmt=markers[row["replicate"]],
        ms=6, color=palette[row["method"]], ecolor=palette[row["method"]],
        markeredgewidth=0.5
    )

# guide lines & labels

ax.axhline(50, ls="--", lw=1, color="red")

ax.set_xticks(range(len(generation_order)))
ax.set_xticklabels([1,2,3,4,5])
ax.set_xlabel("Post-Bottleneck Days",
    fontsize=16)

# ----- y-axis ticks: include 50 explicitly -----
tick_list = [1,2,5,10,20,50,100,200,400]
ax.set_yscale("log")
ax.set_yticks(tick_list)
ax.get_yaxis().set_major_formatter(ScalarFormatter())
ax.set_ylabel("Estimation of bottleneck size",
    fontsize=16)

ax.set_title("Bottleneck size 50, Coverage 10000",
    fontsize=18)
method_handles = [
    Line2D([], [], marker=markers[3], linestyle='',
           markerfacecolor=palette[m], markeredgecolor=palette[m],
           markersize=7, label=m)
    for m in method_order
]

# 2) shape legend (replicates)
replicate_handles = [
    Line2D([], [], marker=markers[r], linestyle='',
           markerfacecolor='grey', markeredgecolor='grey',
           markersize=7, label=f"r{r}")
    for r in sorted(replicate_shift)
]

# ───────── figure-level legend (never clipped) ─────────
leg_methods = fig.legend(          # figure-level legend = never clipped
    handles=method_handles,
    title="Method",
    bbox_to_anchor=(1.02, 0.8),   # right outside, top-aligned
    loc="upper left",
    borderaxespad=0.0,
    frameon=False,
    ncol=1,
    fontsize=13, title_fontsize=14                         # vertical
)

# ---  A second stacked legend for replicates -----------------------
leg_reps = fig.legend(
    handles=replicate_handles,
    title="Replicate",
    bbox_to_anchor=(1.02, 0.50),   # right outside, ~40 % down
    loc="upper left",
    borderaxespad=0.0,
    frameon=False,
    ncol=1,
    fontsize=13, title_fontsize=14
)

# reserve 25 % of the canvas for the legends *before* tightening
fig.subplots_adjust(right=0.75) 


plt.tight_layout()
plt.show()
#fig.savefig("bottleneck_panel.png", dpi=300, bbox_inches="tight")
#print("Saved figure as bottleneck_panel.png")

#plot bottleneck T
#!/usr/bin/env python
"""
Create the ‘Generation 0’ bottleneck panel from H1N1_ob_<method>.csv files.
"""

import glob, re, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.ticker as mticker

# ── 1 ▸ Read & stack every per-method CSV  ────────────────────────────────────
dfs = []
for fp in glob.glob("BottleneckTDataset_noerror/R_input/H1N1_ob_*.csv"):                      # e.g. H1N1_ob_KL.csv
    method = re.search(r"BottleneckTDataset_noerror/R_input/H1N1_ob_(.*)\.csv", fp).group(1)
    d = pd.read_csv(fp)
    d["method"] = method.replace("_", "-")                 # nicer label
    dfs.append(d)

df = pd.concat(dfs, ignore_index=True)                     # ← one tidy table

# ── 2 ▸ Parse ‘recipient’ → true_nb  &  replicate  ───────────────────────────
def parse_rec(rec):
    # matches H1N1_Recipient_<Nb>_<rep>_0
    nb, rep = map(int, re.search(r"_Recipient_(\d+)_([1-5])_", rec).groups())
    return nb, rep

df[["true_nb", "replicate"]] = (df["recipient"]
                                .apply(lambda s: pd.Series(parse_rec(s))))

# ── 3 ▸ Plotting setup  ──────────────────────────────────────────────────────
nb_order = sorted(df["true_nb"].unique())          # [1,10,20,30,40,50]
methods  = ["Beta-binomial-Approximate", "Beta-binomial-Exact",
            "Binomial", "KL", "Presence-Absence"]

palette = {"Beta-binomial-Approximate": "#F48C06",
           "Beta-binomial-Exact"     : "#FFBC42",
           "Binomial"                : "#D7263D",
           "KL"                      : "#1E6091",
           "Presence-Absence"        : "#8ECAE6"}
markers = {1:"o", 2:"s", 3:"v", 4:"^", 5:"P"}

# offsets: block by method, tiny jitter by replicate
half_w   = 0.30
m_step   = 2*half_w / (len(methods)-1)
m_shift  = {m: -half_w+i*m_step for i,m in enumerate(methods)}
r_shift  = {1:-0.04, 2:-0.02, 3:0, 4:0.02, 5:0.04}

plt.rcParams.update({"xtick.labelsize":14, "ytick.labelsize":14,
                     "xtick.major.size":8, "xtick.major.width":1.5,
                     "ytick.major.size":8, "ytick.major.width":1.5})

fig, ax = plt.subplots(figsize=(12,6))

# ── 4 ▸ Scatter + error bars  ────────────────────────────────────────────────
for _, row in df.iterrows():
    x = (nb_order.index(row["true_nb"]) +
         m_shift[row["method"]] +
         r_shift[row["replicate"]])

    ax.errorbar(
        x, row["transmission_bottleneck_size"],
        yerr=[[row["transmission_bottleneck_size"] - row["CI_low"]],
              [row["CI_high"] - row["transmission_bottleneck_size"]]],
        fmt=markers[row["replicate"]],
        ms=6,
        color=palette[row["method"]],
        ecolor=palette[row["method"]],
        markeredgewidth=0.6
    )

# ── 5 ▸ Red dashed “truth” step & guides  ────────────────────────────────────
for i, nb in enumerate(nb_order):
    # draw a dashed red horizontal line that spans the width of that group
    ax.hlines(nb, i-0.45, i+0.45,                   # xmin, xmax
              colors="red", linestyles="--", linewidth=1.5)


# ── 6 ▸ Axes cosmetics  ──────────────────────────────────────────────────────
ax.set_xticks(range(len(nb_order)))
ax.set_xticklabels(nb_order)
ax.set_xlabel("True bottleneck size", fontsize=16)

ax.set_yscale("log")
ax.set_yticks([1, 2, 5, 10, 20, 50, 100, 200, 400])   # ensure 50 shows
ax.yaxis.set_major_formatter(mticker.ScalarFormatter())
ax.set_ylabel("Estimation of bottleneck size", fontsize=16)
ax.set_title("Post-bottleneck 0days", fontsize=18)

# ── 7 ▸ Legends outside the axes  ────────────────────────────────────────────
method_handles = [Line2D([],[], marker=markers[3], ls='',
                         mfc=palette[m], mec=palette[m], ms=7, label=m)
                  for m in methods]
rep_handles    = [Line2D([],[], marker=markers[r], ls='',
                         mfc="grey", mec="grey", ms=7, label=f"r{r}")
                  for r in sorted(r_shift)]

fig.legend(handles=method_handles, title="method",
           loc="upper left", bbox_to_anchor=(1.02,0.8), frameon=False,
    fontsize=13, title_fontsize=14)
fig.legend(handles=rep_handles, title="replicates",
           loc="upper left", bbox_to_anchor=(1.02,0.5), frameon=False,
    fontsize=13, title_fontsize=14)

fig.subplots_adjust(right=0.78)   # reserve space for the legends
plt.tight_layout()

plt.show()
fig.savefig("generation0_panel.png", dpi=300, bbox_inches="tight")
print("Saved → generation0_panel.png")

#plot Bottleneck R
#!/usr/bin/env python
"""
Create the ‘Generation 0’ bottleneck panel from H1N1_ob_<method>.csv files.
"""

import glob, re, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.ticker as mticker

# ── 1 ▸ Read & stack every per-method CSV  ────────────────────────────────────
dfs = []
for fp in glob.glob("BottleneckRDataset_noerror/R_input/H1N1_ob_*.csv"):                      # e.g. H1N1_ob_KL.csv
    method = re.search(r"BottleneckRDataset_noerror/R_input/H1N1_ob_(.*)\.csv", fp).group(1)
    d = pd.read_csv(fp)
    d["method"] = method.replace("_", "-")                 # nicer label
    dfs.append(d)

df = pd.concat(dfs, ignore_index=True)                     # ← one tidy table

# ── 2 ▸ Parse ‘recipient’ → true_nb  &  replicate  ───────────────────────────
def parse_rec(rec):
    # matches H1N1_Recipient_<Nb>_<rep>_0
    nb, rep = map(int, re.search(r"_Recipient_(\d+)_([1-5])_", rec).groups())
    return nb, rep

df[["true_nb", "replicate"]] = (df["recipient"]
                                .apply(lambda s: pd.Series(parse_rec(s))))

# ── 3 ▸ Plotting setup  ──────────────────────────────────────────────────────
nb_order = sorted(df["true_nb"].unique())          # [1,10,20,30,40,50]
methods  = ["Beta-binomial-Approximate", "Beta-binomial-Exact",
            "Binomial", "KL", "Presence-Absence"]

palette = {"Beta-binomial-Approximate": "#F48C06",
           "Beta-binomial-Exact"     : "#FFBC42",
           "Binomial"                : "#D7263D",
           "KL"                      : "#1E6091",
           "Presence-Absence"        : "#8ECAE6"}
markers = {1:"o", 2:"s", 3:"v", 4:"^", 5:"P"}

# offsets: block by method, tiny jitter by replicate
half_w   = 0.30
m_step   = 2*half_w / (len(methods)-1)
m_shift  = {m: -half_w+i*m_step for i,m in enumerate(methods)}
r_shift  = {1:-0.04, 2:-0.02, 3:0, 4:0.02, 5:0.04}

plt.rcParams.update({"xtick.labelsize":14, "ytick.labelsize":14,
                     "xtick.major.size":8, "xtick.major.width":1.5,
                     "ytick.major.size":8, "ytick.major.width":1.5})

fig, ax = plt.subplots(figsize=(12,6))

# ── 4 ▸ Scatter + error bars  ────────────────────────────────────────────────
for _, row in df.iterrows():
    x = (nb_order.index(row["true_nb"]) +
         m_shift[row["method"]] +
         r_shift[row["replicate"]])

    ax.errorbar(
        x, row["transmission_bottleneck_size"],
        yerr=[[row["transmission_bottleneck_size"] - row["CI_low"]],
              [row["CI_high"] - row["transmission_bottleneck_size"]]],
        fmt=markers[row["replicate"]],
        ms=6,
        color=palette[row["method"]],
        ecolor=palette[row["method"]],
        markeredgewidth=0.6
    )

# ── 5 ▸ Red dashed “truth” step & guides  ────────────────────────────────────
for i, nb in enumerate(nb_order):
    # draw a dashed red horizontal line that spans the width of that group
    ax.hlines(nb, i-0.45, i+0.45,                   # xmin, xmax
              colors="red", linestyles="--", linewidth=1.5)

# ── 6 ▸ Axes cosmetics  ──────────────────────────────────────────────────────
ax.set_xticks(range(len(nb_order)))
ax.set_xticklabels(nb_order)
ax.set_xlabel("True bottleneck size", fontsize=16)

ax.set_yscale("log")
ax.set_yticks([1, 2, 5, 10, 20, 50, 100])   # ensure 50 shows
ax.yaxis.set_major_formatter(mticker.ScalarFormatter())
ax.set_ylabel("Estimation of bottleneck size", fontsize=16)
ax.set_title("Post-bottleneck 3days, coverage 2000", fontsize=18)

# ── 7 ▸ Legends outside the axes  ────────────────────────────────────────────
method_handles = [Line2D([],[], marker=markers[3], ls='',
                         mfc=palette[m], mec=palette[m], ms=7, label=m)
                  for m in methods]
rep_handles    = [Line2D([],[], marker=markers[r], ls='',
                         mfc="grey", mec="grey", ms=7, label=f"r{r}")
                  for r in sorted(r_shift)]

fig.legend(handles=method_handles, title="method",
           loc="upper left", bbox_to_anchor=(1.02,0.8), frameon=False,
    fontsize=13, title_fontsize=14)
fig.legend(handles=rep_handles, title="replicates",
           loc="upper left", bbox_to_anchor=(1.02,0.5), frameon=False,
    fontsize=13, title_fontsize=14)

fig.subplots_adjust(right=0.78)   # reserve space for the legends
plt.tight_layout()

plt.show()










