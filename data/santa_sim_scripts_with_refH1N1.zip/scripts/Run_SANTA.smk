Nb=[10,20,30,40,50]
rep=[1,2,3,4,5]

rule all:
    input:
        expand("{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_0.fasta",Nb=Nb, rep=rep),
        expand("{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_20.fasta",Nb=Nb, rep=rep),
        expand("{Nb}/{rep}/stats_Recipient_{Nb}_{rep}.csv",Nb=Nb, rep=rep),
        expand("{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}.fasta",Nb=Nb, rep=rep),
        expand("{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}.xml",Nb=Nb, rep=rep)

rule organise_fasta:
    input:
        fasta="raw_santa/H1N1_Recipient_{Nb}_{rep}.fasta",
        xml="raw_santa/H1N1_Recipient_{Nb}_{rep}.xml"
    output:
        fasta1="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_0.fasta",
        fasta2="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}.fasta",
        xml="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}.xml"
    wildcard_constraints:
        Nb  = "10|20|30|40|50",
        rep = "1|2|3|4|5"
    shell:
        """
        mkdir -p {wildcards.Nb}/{wildcards.rep}
        cp {input.fasta} {output.fasta1}
        cp {input.fasta} {output.fasta2}
        cp {input.xml} {output.xml}
        """

rule run_SantaSim:
    input:
        "{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}.xml"

    output:
        fasta="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_20.fasta",
        csv="{Nb}/{rep}/stats_Recipient_{Nb}_{rep}.csv"
    wildcard_constraints:
        Nb  = "10|20|30|40|50",
        rep = "1|2|3|4|5"
    shell:
        """
    cd {wildcards.Nb}/{wildcards.rep}
    java -Xmx300g -jar /home3/2748683z/R_pub/santa-sim/dist/santa.jar /home3/2748683z/R_pub/First_simulation/{input}                                       
    cd /home3/2748683z/R_pub/First_simulation/
        """