import math

coverage=[10,100,1000,10000]
rep=[1,2,3,4,5]
g=12
Nb=50

rule all:
    input:
        expand("CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R1.fastq",Nb=Nb, rep=rep,cover=coverage),    
        expand("CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R2.fastq",Nb=Nb, rep=rep,cover=coverage),
        expand("CoverageDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{cover}.bam",Nb=Nb, rep=rep,cover=coverage),
        expand("CoverageDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_{cover}_entropy.txt",Nb=Nb, rep=rep,cover=coverage)

rule wgsim_single:
    input:  
        fasta="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_12.fasta"
    output:
        fastq1="CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R1.fastq",
        fastq2="CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R2.fastq"
    params:
        N=lambda wc, math=math: math.ceil(int(wc.cover)*13158 / 125),
        outdir=lambda wc: f"CoverageDataset_noerror/raw_reads/H1N1_Recipient_{wc.Nb}_{wc.rep}_{wc.cover}"
    shell:
        """
        mkdir -p CoverageDataset_noerror/raw_reads
        iss generate --genomes {input.fasta} --abundance uniform --mode perfect --n_reads {params.N} --output {params.outdir}
        rm {params.outdir}_abundance.txt
        rm {params.outdir}.iss.tmp.0.vcf
        rm {params.outdir}.iss.tmp.1.vcf
        """


# Diversitools path: DiversiTools/bin/diversiutils.pl
#snakemake --cores 4 -s Create_coverage_dataset.smk 

rule mapping:
    input:
        fastq1="CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R1.fastq",
        fastq2="CoverageDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{cover}_R2.fastq"
    output:
        sam=temp("CoverageDataset_noerror/mapped_reads/{Nb}_{rep}_{cover}.sam"),
        bam=temp("CoverageDataset_noerror/mapped_reads/{Nb}_{rep}_{cover}.bam"),
        sort_bam="CoverageDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{cover}.bam"
    shell:
        """
          mkdir -p CoverageDataset_noerror/mapped_reads  
          bowtie2 -x H1N1_index/H1N1_index -1 {input.fastq1} -2 {input.fastq2} -S {output.sam}
          samtools view -bS {output.sam} > {output.bam}
          samtools sort -o {output.sort_bam} {output.bam}
          samtools index {output.sort_bam}  
        """


rule variant_calling:
    input:
        bam="CoverageDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{cover}.bam"
    
    output:
        entropy="CoverageDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_{cover}_entropy.txt"
    params:
        prefix=lambda wc: f"CoverageDataset_noerror/variant_calling/H1N1_Recipient_{wc.Nb}_{wc.rep}_{wc.cover}"
    shell:
        """
        mkdir -p CoverageDataset_noerror/variant_calling
        DiversiTools/bin/diversiutils_linux -bam {input.bam} -ref H1N1_index/H1N1.fasta -stub {params.prefix}

        """
    