import math

generation=[4,8,12,16,20]
rep=[1,2,3,4,5]
coverage=10000
Nb=50

rule all:
    input:
        expand("GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R1.fastq",Nb=Nb, rep=rep,gener=generation),    
        expand("GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R2.fastq",Nb=Nb, rep=rep,gener=generation),
        expand("GenerationDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{gener}.bam",Nb=Nb, rep=rep,gener=generation),
        expand("GenerationDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_{gener}_entropy.txt",Nb=Nb, rep=rep,gener=generation)

rule wgsim_single:
    input:  
        fasta="{Nb}/{rep}/H1N1_Recipient_{Nb}_{rep}_{gener}.fasta"
    output:
        fastq1="GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R1.fastq",
        fastq2="GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R2.fastq"
    params:
        N= math.ceil(int(coverage)*13158 / 125),
        outdir=lambda wc: f"GenerationDataset_noerror/raw_reads/H1N1_Recipient_{wc.Nb}_{wc.rep}_{wc.gener}"
    shell:
        """
        mkdir -p GenerationDataset_noerror/raw_reads
        iss generate --genomes {input.fasta} --abundance uniform --mode perfect --n_reads {params.N} --output {params.outdir}
        rm {params.outdir}_abundance.txt
        rm {params.outdir}.iss.tmp.0.vcf
        rm {params.outdir}.iss.tmp.1.vcf
        """


# Diversitools path: DiversiTools/bin/diversiutils.pl
#snakemake --cores 4 -s Create_generation_dataset_noerror.smk 

rule mapping:
    input:
        fastq1="GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R1.fastq",
        fastq2="GenerationDataset_noerror/raw_reads/H1N1_Recipient_{Nb}_{rep}_{gener}_R2.fastq"
    output:
        sam=temp("GenerationDataset_noerror/mapped_reads/{Nb}_{rep}_{gener}.sam"),
        bam=temp("GenerationDataset_noerror/mapped_reads/{Nb}_{rep}_{gener}.bam"),
        sort_bam="GenerationDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{gener}.bam"
    shell:
        """
          mkdir -p GenerationDataset_noerror/mapped_reads  
          bowtie2 -x H1N1_index/H1N1_index -1 {input.fastq1} -2 {input.fastq2} -S {output.sam}
          samtools view -bS {output.sam} > {output.bam}
          samtools sort -o {output.sort_bam} {output.bam}
          samtools index {output.sort_bam}  
        """


rule variant_calling:
    input:
        bam="GenerationDataset_noerror/mapped_reads/H1N1_Recipient_{Nb}_{rep}_{gener}.bam"
    
    output:
        entropy="GenerationDataset_noerror/variant_calling/H1N1_Recipient_{Nb}_{rep}_{gener}_entropy.txt"
    params:
        prefix=lambda wc: f"GenerationDataset_noerror/variant_calling/H1N1_Recipient_{wc.Nb}_{wc.rep}_{wc.gener}"
    shell:
        """
        mkdir -p GenerationDataset_noerror/variant_calling
        DiversiTools/bin/diversiutils_linux -bam {input.bam} -ref H1N1_index/H1N1.fasta -stub {params.prefix}

        """
    