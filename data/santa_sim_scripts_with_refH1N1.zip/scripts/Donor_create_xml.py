import xml.etree.ElementTree as ET


def prettify(elem, level=0):
    """
    Return an ElementTree element with pretty-printed indentation.
    """
    indent = "  "
    i = "\n" + level * indent
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + indent
        for child in elem:
            prettify(child, level + 1)
        if not child.tail or not child.tail.strip():
            child.tail = i
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = i
    return elem

def bottleneck_envent_sim(samplingSchedule):
    for Nb in [1,10,20,30,40,50]:
        for Nb_relicates in range(1,6):
                print(Nb_relicates)
                Nb_sampler=ET.SubElement(samplingSchedule,"sampler")
                Nb_atGeneration=ET.SubElement(Nb_sampler,"atGeneration")
                Nb_atGeneration.text=str(20)
                Nb_fileName=ET.SubElement(Nb_sampler,"fileName")
                Nb_fileName.text=f"H1N1_Recipient_{Nb}_{Nb_relicates}.fasta"
                Nb_alignment=ET.SubElement(Nb_sampler,"alignment")
                Nb_sampleSize=ET.SubElement(Nb_alignment,"sampleSize")
                Nb_sampleSize.text=str(Nb)
                Nb_format=ET.SubElement(Nb_alignment,"format")
                Nb_format.text="FASTA"
                Nb_label=ET.SubElement(Nb_alignment,"label")
                Nb_label.text=f"H1N1_Recipient_{Nb}_{Nb_relicates}_%s"

def santa_xml(rep,grow_r,pop_size,fasta_file):
    santa = ET.Element("santa")
######################################################################################
    replicates = ET.SubElement(santa, "replicates")
    replicates.text=str(rep)
######################################################################################
    simulation = ET.SubElement(santa, "simulation")
######################################################################################
    genome=ET.SubElement(simulation, "genome")
    length=ET.SubElement(genome,"length")
    length.text=str(13158)
    sequences=ET.SubElement(genome,"sequences")
    sequences.set("file",f"{fasta_file}")
    feature=ET.SubElement(genome,"feature")
    name=ET.SubElement(feature,"name")
    name.text="H1N1"
    type=ET.SubElement(feature,"type")
    type.text="nucleotide"
    coordinates=ET.SubElement(feature,"coordinates")
    coordinates.text="1-13158"
######################################################################################
    population=ET.SubElement(simulation, "population")
    populationSize=ET.SubElement(population, "populationSize")
    populationSize.text=str(pop_size)
    inoculum=ET.SubElement(population, "inoculum")
    inoculum.text="all"
######################################################################################
    populationType=ET.SubElement(simulation, "populationType")
    populationType.text="dynamicPopulation"
#######################################################################################
    growthModel=ET.SubElement(simulation, "growthModel")
    growthRate=ET.SubElement(growthModel, "growthRate")
    growthRate.text=str(grow_r)
    carryingPopulation=ET.SubElement(growthModel, "carryingPopulation")
    carryingPopulation.text=str(1500000)
#######################################################################################
    fitnessFunction=ET.SubElement(simulation, "fitnessFunction")
    neutralFitness=ET.SubElement(fitnessFunction, "neutralFitness")
    fitness_feature=ET.SubElement(neutralFitness, "feature")
    fitness_feature.text="H1N1"
    sites=ET.SubElement(neutralFitness, "sites")
    sites.text="1-13158"
#######################################################################################
    mutator=ET.SubElement(simulation, "mutator")
    nucleotideMutator=ET.SubElement(mutator,"nucleotideMutator")
    mutationRate=ET.SubElement(nucleotideMutator,"mutationRate")
    mutationRate.text="1.5e-05"
    transitionBias=ET.SubElement(nucleotideMutator,"transitionBias")
    transitionBias.text=str(2)
#######################################################################################
    replicator=ET.SubElement(simulation, "replicator")
    clonalReplicator=ET.SubElement(replicator, "clonalReplicator")
#######################################################################################
    epoch=ET.SubElement(simulation, "epoch")
    generationCount=ET.SubElement(epoch,"generationCount")
    generationCount.text=str(20)
#######################################################################################
    samplingSchedule=ET.SubElement(simulation, "samplingSchedule")
#######################################################################################
    F_sampler=ET.SubElement(samplingSchedule,"sampler")
    atFrequency=ET.SubElement(F_sampler,"atFrequency")
    atFrequency.text=str(1)
    F_fileName=ET.SubElement(F_sampler,"fileName")
    F_fileName.text="stats_Donor.csv"
    statistics=ET.SubElement(F_sampler,"statistics")
#######################################################################################
    G_sampler=ET.SubElement(samplingSchedule,"sampler")
    atGeneration=ET.SubElement(G_sampler,"atGeneration")
    atGeneration.text=str(20)
    G_fileName=ET.SubElement(G_sampler,"fileName")
    G_fileName.text="H1N1_Donor.csv"
    alleleFrequency=ET.SubElement(G_sampler,"alleleFrequency")
    G_feature=ET.SubElement(alleleFrequency,"feature")
    G_feature.text="H1N1"
    G_sites=ET.SubElement(alleleFrequency,"sites")
    G_sites.text="1-13158"
#######################################################################################
    S_sampler=ET.SubElement(samplingSchedule,"sampler")
    S_atGeneration=ET.SubElement(S_sampler,"atGeneration")
    S_atGeneration.text=str(20)
    S_fileName=ET.SubElement(S_sampler,"fileName")
    S_fileName.text="H1N1_Donor.fasta"
    S_alignment=ET.SubElement(S_sampler,"alignment")
    S_sampleSize=ET.SubElement(S_alignment,"sampleSize")
    S_sampleSize.text=str(1500000)
    S_format=ET.SubElement(S_alignment,"format")
    S_format.text="FASTA"
    S_label=ET.SubElement(S_alignment,"label")
    S_label.text="H1N1_Donor_%s"
#######################################################################################
    bottleneck_envent_sim(samplingSchedule)
#######################################################################################
    root=prettify(santa)
    return(root)

replicates=1
grow_rate=1.8
pop_size=40
fasta_file="H1N1.fasta"
root=santa_xml(replicates,grow_rate,pop_size,fasta_file)
tree = ET.ElementTree(root)
tree.write(f"H1N1_Donor_Bottleneck.xml", encoding="utf-8", xml_declaration=False)








